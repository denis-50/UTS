package com.example.sepatu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
